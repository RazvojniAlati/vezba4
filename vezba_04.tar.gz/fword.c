#include <stdio.h>
#include <string.h>

#include "helper.h"

int ccnt = 0;
int argl;
char *starg;

int findword(int x)
{
  if( x == starg[ccnt] )
    ccnt++;
  else if( x == starg[0] )
    ccnt = 1;
  else
    ccnt = 0;
  return ( ccnt == argl ) ? 1 : 0;
}

int main(int argc, char *argv[])
{
  if(argc != 2)
  {
    fprintf(stderr, "\n\nfword: broj argumenata mora biti 1!\n\n");
    return 10;
  }
  else
  {
    starg = argv[1];
    argl = strlen(starg);
  }
  return loop(findword) ? 0 : 1;
}