#include <stdio.h>
#include "helper.h"

int ucase(int c)
{
  if((c>='a') && (c<='z'))
    putchar(c-('a'-'A'));
  else
    putchar(c);
  return 0;
}

int main()
{
  return loop(ucase);
}
