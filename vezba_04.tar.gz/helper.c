#include <stdio.h>
#include "helper.h"

int loop(int (*worker)(int))
{
  int r;
  int st = 0;
  
  while( (r = getchar()) != EOF )
  {
    if( (st = worker(r)) != 0 )
      break;
  }
  return st;
}
