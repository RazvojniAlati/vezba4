#include <stdio.h>

int main(int argc, char* argv[])
{
  printf("Komanda je pozvana kao>>>: %s\n", argv[0]);
  if(argc>1)
  {
    printf("Prvi argument je>>> %s\n", argv[1]);
    return 0;
  }
  else
  {
    return 1;
  }
}
