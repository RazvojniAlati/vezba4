#ifndef _HELPER_H
#define _HELPER_H


int loop(int (*worker)(int));

#endif
