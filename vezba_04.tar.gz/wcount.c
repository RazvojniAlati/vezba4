#include <stdio.h>

#include "helper.h"

int wcnt;

int word_counter(int x)
{
	static int dsp = 0;
	if( (x==' ') || (x=='\n') )
	{
		if( ! dsp )
		{
			wcnt++;
			dsp = 1;
		}
	}
	else
	{
		dsp = 0;
	}
	return 0;
}

int main()
{
	int status;
	wcnt = 0;
	if( (status = loop(word_counter)) )
		fprintf(stderr, "\n\nNesto nije u redu!\n");
	else
		printf("%d", wcnt);
	return status;
}
